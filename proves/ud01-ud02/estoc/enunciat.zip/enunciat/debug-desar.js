import fs from "node:fs";
import { Inventari } from "./src/inventari.js";

const origen = "./dades/inventari.json";
const desti = "./dades/prova-desar.json";

fs.copyFileSync(origen, desti);

const inventari = new Inventari(desti);
inventari.desar();

console.log(fs.readFileSync(desti, "utf-8"));
