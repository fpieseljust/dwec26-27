import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { Inventari } from "../src/inventari.js";

export function crearEntornTemporal() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "prova-inventari-"));
  const ruta = path.join(dir, "inventari.json");

  fs.writeFileSync(ruta, "[]", "utf-8");

  return {
    inventari: new Inventari(ruta),
    ruta,
    netejar() {
      fs.rmSync(dir, { recursive: true, force: true });
    },
  };
}
