import { test } from "node:test";

// Escriu ací les proves que demana l'enunciat.
// Pots importar assert de "node:assert/strict" i els helpers de "./helpers.js".

test.todo("valorTotal suma tots els productes");
test.todo("buscarPerNom és insensible a majúscules i parcial");
test.todo("retirar valida l'estoc i la quantitat");
test.todo("desar i carregar conserven els productes");
test.todo("estocBaix, ordenarPerPreu i generarInforme funcionen");
