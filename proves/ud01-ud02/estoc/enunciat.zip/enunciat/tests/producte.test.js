import assert from "node:assert/strict";
import { test } from "node:test";
import { Producte } from "../src/producte.js";

test("exemple: valorEstoc multiplica preu per estoc", () => {
  const producte = new Producte(1, "Teclat", 20, 3);
  assert.equal(producte.valorEstoc, 60);
});

test.todo("aplicarDescompte aplica el percentatge i arredoneix");
test.todo("aplicarDescompte rebutja percentatges invàlids");
test.todo("ProductePereixedor hereta i aplica el descompte extra");
