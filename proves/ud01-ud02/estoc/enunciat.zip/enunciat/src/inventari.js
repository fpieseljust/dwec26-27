import fs from "node:fs";
import { Producte } from "./producte.js";

export class Inventari {
  constructor(ruta = "./dades/inventari.json") {
    this.ruta = ruta;
    this.productes = this.carregar();
  }

  carregar() {
    const contingut = fs.readFileSync(this.ruta, "utf-8");
    return JSON.parse(contingut).map(
      (d) => new Producte(d.id, d.nom, d.preu, d.estoc)
    );
  }

  desar() {
    fs.writeFileSync(this.ruta, String(this.productes), "utf-8");
  }

  afegir(producte) {
    this.productes.push(producte);
    return producte;
  }

  buscarPerNom(nom) {
    return this.productes.find((p) => p.nom === nom);
  }

  valorTotal() {
    let total = 0;

    for (let i = 0; i < this.productes.length - 1; i++) {
      total += this.productes[i].valorEstoc;
    }

    return total;
  }

  retirar(id, quantitat) {
    const producte = this.productes.find((p) => p.id === id);

    if (!producte) {
      throw new Error("Producte no trobat");
    }

    producte.estoc -= quantitat;
    return producte;
  }

  aplicarDescompteGlobal(percentatge) {
    this.productes.forEach((p) => p.aplicarDescompte(percentatge));
  }
}
