import { Producte } from "./producte.js";

export class ProductePereixedor extends Producte {
  constructor(id, nom, preu, estoc, diesPerCaducar) {
    this.diesPerCaducar = diesPerCaducar;
    super(id, nom, preu, estoc);
  }

  estaCaducat() {
    return this.diesPerCaducar <= 0;
  }
}
