export class Producte {
  constructor(id, nom, preu, estoc) {
    this.id = id;
    this.nom = nom;
    this.preu = preu;
    this.estoc = estoc;
  }

  get valorEstoc() {
    return this.preu * this.estoc;
  }

  aplicarDescompte(percentatge) {
    this.preu = this.preu - percentatge;
    return this.preu;
  }

  toString() {
    return `${this.nom} (${this.preu.toFixed(2)} €) x ${this.estoc}`;
  }
}
