import { Inventari } from "./src/inventari.js";
import { ProductePereixedor } from "./src/productePereixedor.js";

const inventari = new Inventari("./dades/inventari.json");

console.log("Productes:", inventari.productes.length);
console.log("Valor total:", inventari.valorTotal());

console.log('Cerca "Teclat":', inventari.buscarPerNom("Teclat")?.nom);
console.log('Cerca "teclat":', inventari.buscarPerNom("teclat")?.nom);
console.log('Cerca "clat":', inventari.buscarPerNom("clat")?.nom);

const teclat = inventari.buscarPerNom("Teclat");
inventari.retirar(teclat.id, 999);
console.log("Estoc després de retirar 999:", teclat.estoc);

inventari.aplicarDescompteGlobal(10);
console.log("Preu després del 10 %:", teclat.preu);

const iogurt = new ProductePereixedor(4, "Iogurt", 1.2, 6, 3);
console.log("Iogurt caducat?", iogurt.estaCaducat());
